# Thunder Reflex — Android Project

Updated neon lightning tap-speed game for Android.

## Features
- 15, 30, and 60-second game modes
- Live tap count, TPS, and countdown timer
- Personal best per duration, top score, average TPS, total rounds, and recent history
- Local score/settings persistence on the device
- Neon glow, animated lightning, and responsive touch feedback
- Optional sound and vibration; works offline

## Build
The project is packaged as an Android WebView app. The repository GitHub Actions workflow extracts this project and runs `gradle assembleDebug`.
