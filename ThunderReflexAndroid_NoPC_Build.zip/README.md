# Thunder Reflex — Android Studio Project

A neon lightning tap-speed reflex game packaged as an Android WebView app.

## Features
- 5, 10, 30, and 60-second rounds
- Live tap count, taps per second (TPS), and countdown
- Best score per duration, recent session history, and statistics
- Settings for round duration, sound, and vibration
- Offline-first: the game assets are bundled in the app
- Responsive neon interface inspired by arcade lightning aesthetics

## Build and install
1. Install Android Studio (current stable) with Android SDK.
2. Open this folder in Android Studio.
3. Let Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Install the generated APK on your Android phone.

The project uses Android Gradle Plugin 8.7.3 and Java 17. If Android Studio asks to update Gradle/plugin versions, use its suggested compatible versions.

## Package
`com.example.thunderreflex`

This is an original implementation and does not use Thunder Reflex's original assets or branding beyond the project name you requested.
